-- Anders Johnsson, anders.johnsson@volvocars.com
-- v1.0 2014-01-03
-- create doip-udp protocol and its fields

p_doip_udp = Proto ("udp-doip","DoIP UDP")

local f_version =     ProtoField.uint16("doip_udp.version", "DoIP version", base.HEX)
local f_pltype =      ProtoField.uint16("doip_udp.pltype", "PL type", base.HEX)
local f_pllen =       ProtoField.uint32("doip_udp.pllen", "PL length", base.HEX)
local f_payload =     ProtoField.bytes("doip_udp.payload", "Payload")
local f_nackcode =    ProtoField.uint8("doip_udp.nackcode", "NACK code", base.HEX)
local f_vin =         ProtoField.string("doip_udp.vin", "VIN")
local f_addr =        ProtoField.uint16("doip_udp.addr", "Address", base.HEX)
local f_EID =         ProtoField.bytes("doip_udp.EID", "EID")
local f_GID =         ProtoField.bytes("doip_udp.GID", "GID")
local f_factreq =     ProtoField.uint8("doip_udp.factreq", "Furter action req", base.HEX)
local f_syncstat =    ProtoField.uint8("doip_udp.syncstat", "Sync status", base.HEX)
local f_diagmode =    ProtoField.uint8("doip_udp.diagmode", "Diag power mode", base.HEX)
local f_nodetype =    ProtoField.uint8("doip_udp.nodetype", "Node type", base.HEX)
local f_maxsockets =  ProtoField.uint8("doip_udp.maxsockets", "Max sockets", base.HEX)
local f_opensockets = ProtoField.uint8("doip_udp.opensockets", "Open sockets", base.HEX)
local f_mds =         ProtoField.uint32("doip_udp.mds", "Max data size", base.HEX)

p_doip_udp.fields = {
				
				
				f_addr,
				f_diagmode,
				f_EID,
				f_factreq,
				f_GID,
				f_maxsockets,
				f_nackcode,
				f_nodetype,
				f_opensockets,	
				f_payload,  
				f_pllen,  
				f_pltype,
				f_syncstat,
				f_version,
				f_vin     
				}

local pltypes = {
			[0x0000]="Generic DoIP header negative ack", 
			[0x0001]="Vehicle identification request msg", 
			[0x0002]="Vehicle identification request msg with EID", 
			[0x0003]="Vehicle identification request msg with VIN", 
			[0x0004]="Vehicle announcement msg/Vehicle identification response msg", 
			[0x0005]="Routing activation request",
			[0x0006]="Routing activation response",
			[0x0007]="Alive check request",
			[0x0008]="Alive check response",
			[0x4001]="DoIP entity status request",
			[0x4002]="DoIP entity status response",
			[0x4003]="Diagnostic power mode information request",
			[0x4004]="Diagnostic power mode information response",
			[0x8001]="Diagnostic message",
			[0x8002]="Diagnostic message positive ack",
			[0x8003]="Diagnostic message negative ack"
			} 

local nackcodes = {
			  [0x00]="Incorrect pattern format",
			  [0x01]="Unknown payload type",
			  [0x02]="Message too large",
			  [0x03]="Out of memory",
			  [0x04]="Invalid payload length"
			  }	

-- doip dissector function
function p_doip_udp.dissector (buf, pkt, root)
	-- validate packet length is adequate, otherwise quit
	if buf:len() == 0 then 
		return 
	end
	-- Set protocol column
	pkt.cols.protocol = p_doip_udp.name
	
	
	-- create subtree for doip
	subtree = root:add(p_doip_udp, buf(0))
	subtree:append_text(", Command details in the tree below")
	
	-- add protocol fields to subtree
	
	-- DoIP version
	subtree:add(f_version, buf(0,2))
	
	-- Payload type (hex)
	local pltype = buf(2,2):uint()
	-- Payload type (desc)
	local pltxt = pltypes[pltype]
	if pltxt == nil then 
		pltxt = "No description"
	end
	-- Add Payload type + desc 
	subtree:add(f_pltype, buf(2,2)):append_text(" ("..pltxt..")")
	
	-- Payload length
	subtree:add(f_pllen, buf(4,4)):append_text(" ("..buf(4,4):uint().." bytes)")
	
	-- Payload raw bytes
	if buf:len() > 8 then
		subtree:add(f_payload, buf(8,buf:len()-8))
	end
	
	-- Specific fields for each payload type
	if pltype == 0x0000 then
		local nacktxt = nackcodes[buf(8,1):uint()]
		if nacktxt == nil then 
			nacktxt = "No description"
		end
		subtree:add(f_nackcode , buf(8,1)):append_text(" ("..nacktxt..")")
		-- Set info column
		pkt.cols.info = "Type: 0x"..buf(2,2)..", NACK Code: 0x"..buf(8,1).." ("..nacktxt..")"
		return
	end
	
	if pltype == 0x0001 then
		pkt.cols.info = "Type: 0x"..buf(2,2)
		return
	end 

	if pltype == 0x0002 then
		subtree:add(f_EID, buf(8,6))
		pkt.cols.info = "Type: 0x"..buf(2,2)..", EID: "..buf(8,6)
		return
	end 

	if pltype == 0x0003 then
		subtree:add(f_vin, buf(8,17))
		pkt.cols.info = "Type: 0x"..buf(2,2)..", VIN: "..buf(8,17):string()
		return
	end 

	if pltype == 0x0004 then
		subtree:add(f_vin, buf(8,17))
		subtree:add(f_addr, buf(25,2))
		subtree:add(f_EID, buf(27,6))
		subtree:add(f_GID, buf(33,6))
		subtree:add(f_factreq, buf(39,1))
		--subtree:add(f_syncstat, buf(40,1))
		pkt.cols.info = "* Vehicle Announcement, EID: "..buf(27,6)..", VIN: "..buf(8,17):string()..", GID: "..buf(33,6)
		return
	end
	
	if pltype == 0x4001 then
		pkt.cols.info = "Type: 0x"..buf(2,2)
		return
	end 

	if pltype == 0x4002 then
		subtree:add(f_nodetype, buf(8,1))
		subtree:add(f_maxsockets, buf(9,1))
		subtree:add(f_opensockets, buf(10,1))
		subtree:add(f_mds, buf(11,4))
		pkt.cols.info = "Type: 0x"..buf(2,2)..", Node type: 0x"..buf(8,1)..", Max sockets: 0x"..buf(9,1)..", Open sockets: 0x"..buf(10,1)
		return
	end 

	if pltype == 0x4003 then
		pkt.cols.info = "Type: 0x"..buf(2,2)
		return
	end 

	if pltype == 0x4004 then
		subtree:add(f_diagmode , buf(8,1))
		pkt.cols.info = "Type: 0x"..buf(2,2)..", Diag Power Mode: 0x"..buf(8,1)
		return
	end

	
end

-- Initialization routine
function p_doip_udp.init()
end

-- register a chained dissector for port 13400
local udp_dissector_table = DissectorTable.get("udp.port")
udp_dissector = udp_dissector_table:get_dissector(13400)

-- you can call udp_dissector from function p_doip_udp.dissector above
-- so that the previous dissector gets called
udp_dissector_table:add(13400, p_doip_udp)
