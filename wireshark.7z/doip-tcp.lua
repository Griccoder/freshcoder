-- Anders Johnsson, anders.johnsson@volvocars.com
-- v1.0 2014-01-03
-- v1.1 2014-05-09  Added missing ECUs, increased length of diag data field -> 1000 bytes

-- create doip-tcp protocol and its fields

local ecus = {
		[0x1FFF]="(All)",
		[0x1401]="ASDM",
		[0x1212]="AUD",
		[0x1701]="BBM",
		[0x1635]="BECM",
		[0x1B61]="BMS",
		[0x1023]="BNCM",
		[0x1022]="BSRM",
		[0x1A11]="CCM",
		[0x1650]="CDD",
		[0x1A01]="CEM",
		[0x1241]="CSD",
		[0x1242]="CSDM",
		[0x1A12]="DDM",
		[0x1638]="DEM",
		[0x1201]="DHU1",
		[0x120F]="DHU2",
		[0x1801]="DIM1",
		[0x1013]="DIM2",
		[0x1253]="DIS1",
		[0x1853]="DIS2",
		[0x1012]="DMM",
		[0x1B75]="DPOD",
		[0x1B74]="DRM",
		[0x1514]="DVR",
		[0x1630]="ECM",
		[0x1633]="EGSM",
		[0x163A]="ESM",
		[0x1411]="FLC",
		[0x1444]="FLR",
		[0x1431]="FSRL",
		[0x1430]="FSRR",
		[0x1BB3]="HCML",
		[0x1BB4]="HCMR",
		[0x1251]="HUD1",
		[0x1851]="HUD2",
		[0x1655]="HVCM",
		[0x1637]="IEM",
		[0x1636]="IGM",
		[0x1201]="IHU1",
		[0x120F]="IHU2",
		[0x1A30]="ILCM",
		[0x163E]="ISGM",
		[0x1B76]="LPOD",
		[0x1631]="MGM",
		[0x1652]="MVBM",
		[0x163D]="MVCM",
		[0x1651]="MVEM",
		[0x1634]="OBC",
		[0x1460]="PAS",
		[0x1639]="PCM",
		[0x1214]="PDCM",
		[0x1A13]="PDM",
		[0x1A54]="PNS",
		[0x1A15]="POT",
		[0x1B77]="PPOD",
		[0x1674]="PSCM100FIT",
		[0x1670]="PSCM1",
		[0x1720]="PSCM10FIT",
		[0x1244]="PSD",
		[0x1BB5]="RCML",
		[0x1BB7]="RCMM",
		[0x1BB6]="RCMR",
		[0x1510]="RML",
		[0x1511]="RMR",
		[0x1A21]="RLDM",
		[0x1B78]="RPOD",
		[0x1A22]="RRDM",
		[0x1213]="RSEM",
		[0x1B62]="RVCM",
		[0x1672]="SAS",
		[0x1615]="SCL",
		[0x1A23]="SDL",
		[0x1A24]="SDR",
		[0x1A29]="SMB",
		[0x1A31]="SMBL",
		[0x1A32]="SMBR",
		[0x1A27]="SMD",
		[0x1A28]="SMP",
		[0x1450]="SODL",
		[0x1451]="SODR",
		[0x1654]="SPNS",
		[0x1C01]="SRS",
		[0x1614]="SUM",
		[0x1B72]="SWM",
		[0x163C]="TACM",
		[0x1011]="TCAM",
		[0x1632]="TCM",
		[0x1601]="VDDM",
		
		[0x0e80]="TST",
		[0x1001]="VGM",
			} 

	
p_doip_tcp = Proto ("tcp-doip","DoIP TCP")


local f_version =     ProtoField.uint16("doip_tcp.version", "DoIP version", base.HEX)
local f_pltype =      ProtoField.uint16("doip_tcp.pltype", "PL type", base.HEX)
local f_pllen =       ProtoField.uint32("doip_tcp.pllen", "PL length", base.DEC)
local f_payload =     ProtoField.bytes("doip_tcp.payload", "Payload")
local f_nackcode =    ProtoField.uint8("doip_tcp.nackcode", "NACK code", base.HEX)
local f_SA =          ProtoField.uint16("doip_tcp.sa", "Source address", base.HEX)
local f_TA =          ProtoField.uint16("doip_tcp.ta", "Target address", base.HEX)
local f_userdata =    ProtoField.bytes("doip_tcp.userdata", "User data")
local f_diagdata =    ProtoField.string("doip_tcp.diagdata", "Diag data")
local f_ackcode =     ProtoField.uint8("doip_tcp.ackcode", "ACK code", base.HEX)
local f_diagnackcode =ProtoField.uint8("doip_tcp.diagnackcode", "Diag NACK code", base.HEX)
local f_acttype1 =    ProtoField.uint16("doip_tcp.acttype1", "Activation type", base.HEX)
local f_acttype2 =    ProtoField.uint8("doip_tcp.acttype2", "Activation type", base.HEX)
local f_testeradr =   ProtoField.uint16("doip_tcp.testeradr", "Tester address", base.HEX)
local f_doipgwadr =   ProtoField.uint16("doip_tcp.doipgwadr", "Doip gw address", base.HEX)
local f_actrespcode = ProtoField.uint8("doip_tcp.actrespcode", "Activation resp code", base.HEX)
local f_SA_id =       ProtoField.string("doip_tcp.sa_id", "Src ECU")
local f_TA_id =       ProtoField.string("doip_tcp.ta_id", "Targ ECU")
local f_service =     ProtoField.uint8("doip_tcp.service", "Service", base.HEX)



p_doip_tcp.fields = {
				f_ackcode,
				f_actrespcode,
				f_acttype1,
				f_acttype2,
				f_diagdata,
				f_diagnackcode,
				f_doipgwadr,
				f_nackcode,
				f_payload, 
				f_pllen, 
				f_pltype,
				f_SA,
				f_SA_id,
				f_service,
				f_TA,
				f_TA_id,
				f_testeradr,
				f_userdata,
				f_version
				}

local pltypes = {
			[0x0000]="Generic DoIP header negative ack", 
			[0x0001]="Vehicle identification request msg", 
			[0x0002]="Vehicle identification request msg with EID", 
			[0x0003]="Vehicle identification request msg with VIN", 
			[0x0004]="Vehicle announcement msg/Vehicle identification response msg", 
			[0x0005]="Routing activation request",
			[0x0006]="Routing activation response",
			[0x0007]="Alive check request",
			[0x0008]="Alive check response",
			[0x4001]="DoIP entity status request",
			[0x4002]="DoIP entity status response",
			[0x4003]="Diagnostic power mode information request",
			[0x4004]="Diagnostic power mode information response",
			[0x8001]="Diagnostic message",
			[0x8002]="Diagnostic message positive ack",
			[0x8003]="Diagnostic message negative ack",
			[0xF001]="Disconnect Vehicle (VCC specific)",	
			[0xF002]="Chat text from vehicle (VCC specific)",
			[0xF003]="Chat text to vehicle (VCC specific)"
			} 

local nackcodes = {
			  [0x00]="Incorrect pattern format",
			  [0x01]="Unknown payload type",
			  [0x02]="Message too large",
			  [0x03]="Out of memory",
			  [0x04]="Invalid payload length"
			  }

local diagnackcodes = {
			  [0x02]="Invalid source address",
			  [0x03]="Unknown target address",
			  [0x04]="Diagnostic message too large",
			  [0x05]="Out of memory",
			  [0x06]="Target unreachable",
			  [0x07]="Unknown network",
			  [0x08]="Transport protocol error"
			  }	

local routeactrespcodes = {
			  [0x00]="Routing activation denied due to unknown source address",
			  [0x01]="Routing activation denied because all concurrently supported TCP_DATA sockets are registered and active",
			  [0x02]="Routing activation denied because an SA different from the table connection entry was received on the already activated TCP_DATA socket",
			  [0x03]="Routing activation denied because the SA is already registered and active on a different TCP_DATA socket",
			  [0x04]="Routing activation denied due to missing authentication",
			  [0x05]="Routing activation denied due to rejected confirmation",
			  [0x06]="Routing activation denied due to unsupported routing activation type",
			  [0x10]="Routing successfully activated",
			  [0x11]="Routing will be activated; confirmation required",
			  [0xE1]="Diagnostic subsystem is busy (VCC specific)",
			  [0xE2]="Wrong activation mode (VCC specific)"
			  }	
local routeactmodes = {
			  [0x00]="Default activation",
			  [0xE2]="Local activation (VCC specific)",
			  [0xE3]="Remote activation (VCC specific)"
			  }


-- doip dissector function
function p_doip_tcp.dissector (buf, pkt, root)
	-- validate packet length is adequate, otherwise quit
	if buf:len() == 0 then 
		return 
	end
	
	-- DoIP version
	local doipversion = buf(0,2):uint()
	if doipversion ~= 0x01FE and doipversion ~= 0x02FD then
		return
	end
	
	-- create subtree for doip
	subtree = root:add(p_doip_tcp, buf(0))
	subtree:append_text(", Command details in the tree below")
	
	-- add protocol fields to subtree
	subtree:add(f_version, buf(0,2))
	-- Set protocol column
	pkt.cols.protocol = p_doip_tcp.name
	-- Payload type (hex)
	local pltype = buf(2,2):uint()
	-- Payload type (desc)
	local pltxt = pltypes[pltype]
	if pltxt == nil then 
		pltxt = "No description"
	end
	
	-- Add Payload type + desc 
	subtree:add(f_pltype, buf(2,2)):append_text(" ("..pltxt..")")
	
	-- Payload length
	subtree:add(f_pllen, buf(4,4)):append_text(" bytes")
	
	-- Payload raw bytes
	if buf:len() > 8 then
		subtree:add(f_payload, buf(8,buf:len()-8))
	end
	
	-- Specific fields for each payload type
	if pltype == 0x0000 then
		local nacktxt = nackcodes[buf(8,1):uint()]
		if nacktxt == nil then 
			nacktxt = "No description"
		end
		subtree:add(f_nackcode , buf(8,1)):append_text(" ("..nacktxt..")")
		-- Set info column
		pkt.cols.info = "Type: 0x"..buf(2,2)..", NACK Code: 0x"..buf(8,1).." ("..nacktxt..")"
		return
	end
	
	if pltype == 0x0005 then
		subtree:add(f_SA, buf(8,2))
		if doipversion == 0x01FE then
			subtree:add(f_acttype1, buf(10,2))
			pkt.cols.info = "* Routing activation request Type: 0x"..buf(2,2)..", SA: 0x"..buf(8,2)..", Activation type: 0x"..buf(10,2)
		else
			subtree:add(f_acttype2, buf(10,1))
			pkt.cols.info = "* Routing activation request Type: 0x"..buf(2,2)..", SA: 0x"..buf(8,2)..", Activation type: 0x"..buf(10,1)
		end
		return
	end 

	if pltype == 0x0006 then
		subtree:add(f_testeradr, buf(8,2))
		subtree:add(f_doipgwadr, buf(10,2))
		local routeacttxt = routeactrespcodes[buf(12,1):uint()]
		if routeacttxt == nil then 
			routeacttxt = "No description"
		end
		subtree:add(f_actrespcode, buf(12,1)):append_text(" ("..routeacttxt..")")
		pkt.cols.info = "* Routing activation response Type: 0x"..buf(2,2)..", Tester: 0x"..buf(8,2)..", DoIP gateway: 0x"..buf(10,2)..", Activation resp code: 0x"..buf(12,1)
		return
	end 

	if pltype == 0x0007 then
		subtree:add(f_vin, buf(8,17))
		pkt.cols.info = "Type: 0x"..buf(2,2).." (Alive check request)"
		return
	end 

	if pltype == 0x0008 then
		subtree:add(f_SA, buf(8,2))		
		pkt.cols.info = "Type: 0x"..buf(2,2)..", SA: 0x"..buf(8,2)
		return
	end
	
	if pltype == 0x8001 then
		local ecutxt = ecus[buf(8,2):uint()]
		if ecutxt == nil then 
			ecutxt = "???"
		end
		subtree:add(f_SA, buf(8,2))
		subtree:add(f_SA_id, ecutxt)

		local ecutxt2 = ecus[buf(10,2):uint()]
		if ecutxt2 == nil then 
			ecutxt2 = "???"
		end
		subtree:add(f_TA, buf(10,2))
		subtree:add(f_TA_id, ecutxt2)
		local diagdatatxt
		if buf:len() > 12 then
		  diagdatatxt = formatuserdata(buf(12,buf:len()-12),1000)
		  subtree:add(f_userdata, buf(12,buf:len()-12))
		  subtree:add(f_diagdata, diagdatatxt)
		  if buf(12,1):uint() == 0x7F then
		  	subtree:add(f_service, buf(13,1))
		  else
		  	subtree:add(f_service, buf(12,1))
		  end	
		else
		  diagdatatxt = "n/a"	
		end
		pkt.cols.info = "DoIP: "..getservicedesc(diagdatatxt)
		return
	end 

	if pltype == 0x8002 then
		local ecutxt = ecus[buf(8,2):uint()]
		if ecutxt == nil then 
			ecutxt = "???"
		end
		subtree:add(f_SA, buf(8,2))
		subtree:add(f_SA_id, ecutxt)
		local ecutxt2 = ecus[buf(10,2):uint()]
		if ecutxt2 == nil then 
			ecutxt2 = "???"
		end
		subtree:add(f_TA, buf(10,2))
		subtree:add(f_ackcode, buf(12,1))
		subtree:add(f_TA_id, ecutxt2)
		pkt.cols.info = "DoIP ACK: Type: 0x"..buf(2,2)..", 0x"..buf(8,2).."->0x"..buf(10,2)..", ACK code: 0x"..buf(12,1)
		return
	end 

	if pltype == 0x8003 then
		local ecutxt = ecus[buf(8,2):uint()]
		if ecutxt == nil then 
			ecutxt = "???"
		end
		subtree:add(f_SA, buf(8,2))
		subtree:add(f_SA_id, ecutxt)
		local ecutxt2 = ecus[buf(10,2):uint()]
		if ecutxt2 == nil then 
			ecutxt2 = "???"
		end
		subtree:add(f_TA, buf(10,2))
		local diagnacktxt = diagnackcodes[buf(12,1):uint()]
		if diagnacktxt == nil then 
			diagnacktxt = "No description"
		end
		subtree:add(f_TA_id, ecutxt2)
		subtree:add(f_diagnackcode , buf(12,1)):append_text(" ("..diagnacktxt..")")
		pkt.cols.info = "DoIP NACK: Type: 0x"..buf(2,2)..", SA: 0x"..buf(8,2)..", TA: 0x"..buf(10,2)..", Diag NACK Code: 0x"..buf(12,1).." ("..diagnacktxt..")"
		return
	end 

	
end

-- Initialization routine
function p_doip_tcp.init()
end

-- register a chained dissector for port 13400
local tcp_dissector_table = DissectorTable.get("tcp.port")
tcp_dissector = tcp_dissector_table:get_dissector(13400)

-- you can call tcp_dissector from function p_doip_tcp.dissector above
-- so that the previous dissector gets called
tcp_dissector_table:add(13400, p_doip_tcp)

function formatuserdata(databytes, maxlen)
	-- adds a space between each byte, up to <maxlen> bytes
	local txt = ""
	for var=0,databytes:len()-1 do 
		if var == maxlen then 
			txt = txt.."..."
			break
		end 
		txt = txt..string.sub("0"..string.format("%X", databytes(var,1):uint()),-2).." "
		
	end 
	return(txt)
end

local servicedescs = {
		["10"]="DiagnosticSessionControl",
		["50"]="DiagnosticSessionControl OK",
		["11"]="ECUReset",
		["51"]="ECUReset OK",
		["22"]="ReadDataByIdentifier",
		["62"]="ReadDataByIdentifier OK",
		["2A"]="ReadDataByPeriodicIdentifier",
		["6A"]="ReadDataByPeriodicIdentifier OK",
		["2E"]="WriteDataByIdentifier", 
		["6E"]="WriteDataByIdentifier OK", 
		["2F"]="InputOutputControlByIdentifier",
		["6F"]="InputOutputControlByIdentifier OK",
		["31"]="RoutineControl",
		["71"]="RoutineControl OK",
		["34"]="RequestDownload",
		["74"]="RequestDownload OK",
		["36"]="TransferData",
		["76"]="TransferData OK",
		["37"]="RequestTransferExit",
		["77"]="RequestTransferExit OK",
		["19"]="ReadDTCInformation",
		["59"]="ReadDTCInformation OK",
		["14"]="ClearDiagnosticInformation",
		["54"]="ClearDiagnosticInformation OK",
		["27"]="SecurityAccess",
		["67"]="SecurityAccess OK",
		["3E"]="TesterPresent",
		["7F"]="NRC"
			} 
local NRCs = {
		["10"]="0x10 generalReject",
		["11"]="0x11 serviceNotSupported",
		["12"]="0x12 subFunctionNotSupported",
		["13"]="0x13 incorrectMessageLengthOrInvalidFormat",
		["21"]="0x21 busyRepeatRequest",
		["22"]="0x22 conditionsNotCorrect",
		["24"]="0x24 requestSequenceError",
		["26"]="0x26 FailurePreventsExecutionOfRequestedAction",
		["31"]="0x31 requestOutOfRange",
		["33"]="0x33 securityAccessDenied",
		["35"]="0x35 invalidKey",
		["36"]="0x36 exceedNumberOfAttempts",
		["37"]="0x37 requiredTimeDelayNotExpired",
		["72"]="0x72 generalProgrammingFailure",
		["73"]="0x73 incorrectBlockSequenceCounter",
		["78"]="0x78 requestCorrectlyReceived-ResponsePending",
		["7E"]="0x7E sub-functionNotSupportedInActiveSession",
		["7F"]="0x7F serviceNotSupportedInActiveSession"
			} 


function getservicedesc(diagdatastring)
	local service = string.sub(diagdatastring,1,2)
	local servicetxt = servicedescs[service]
	if servicetxt == nil then 
		return "<no desc>"
	end
	if service == "7F" then
		local NRCtxt = NRCs[string.sub(diagdatastring,7,8)]
		if NRCtxt == nil then 
			NRCtxt = "<no desc>"
		end
		return servicetxt.." "..NRCtxt
	end
	if service == "10" then
		if string.sub(diagdatastring,5,5) == "1" then
			return servicetxt.." (Normal session)"
		elseif string.sub(diagdatastring,5,5) == "2" then
			return servicetxt.." (Prog session)"
		elseif string.sub(diagdatastring,5,5) == "3" then
			return servicetxt.." (Extended session)"
		end
	end
	if service == "36" then
		return servicetxt..",    seq cnt: 0x"..string.sub(diagdatastring,4,5) 
	end
	if service == "34" then
		return servicetxt..", Address: 0x"..string.sub(diagdatastring,10,11)..string.sub(diagdatastring,13,14)..string.sub(diagdatastring,16,17)..string.sub(diagdatastring,19,20)..", Size: 0x"..string.sub(diagdatastring,22,23)..string.sub(diagdatastring,25,26)..string.sub(diagdatastring,28,29)..string.sub(diagdatastring,31,32) 
	end

	if service == "76" then
		return servicetxt..", seq cnt: 0x"..string.sub(diagdatastring,4,5) 
	end
	if service == "22" then
		return servicetxt..", DID: 0x"..string.sub(diagdatastring,4,5)..string.sub(diagdatastring,7,8) 
	end
	if service == "62" then
		return servicetxt..", DID: 0x"..string.sub(diagdatastring,4,5)..string.sub(diagdatastring,7,8)..", Data: "..string.sub(diagdatastring,10) 
	end
	if service == "2F" then
		return servicetxt..", DID: 0x"..string.sub(diagdatastring,4,5)..string.sub(diagdatastring,7,8) 
	end
	if service == "2E" then
		return servicetxt..", DID: 0x"..string.sub(diagdatastring,4,5)..string.sub(diagdatastring,7,8) 
	end
	if service == "31" then
		return servicetxt..", RI: 0x"..string.sub(diagdatastring,7,8)..string.sub(diagdatastring,10,11) 
	end
	if service == "77" then
		return servicetxt..", CS: 0x"..string.sub(diagdatastring,4,5)..string.sub(diagdatastring,7,8) 
	end
	if service == "74" then
		return servicetxt..", maxNumberOfBlockLength: 0x"..string.sub(diagdatastring,7,8)..string.sub(diagdatastring,10,11) 
	end
	if service == "50" then
		return servicetxt..", P2serverMax: 0x"..string.sub(diagdatastring,7,8)..string.sub(diagdatastring,10,11)..", P2serverMax*: 0x"..string.sub(diagdatastring,13,14)..string.sub(diagdatastring,16,17) 
	end



	return servicetxt
end

function bytepos2stringpos(pos)
	return (pos-1)*3 +1
end
